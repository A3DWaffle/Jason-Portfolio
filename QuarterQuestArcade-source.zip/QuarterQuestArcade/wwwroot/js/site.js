// Gets the list of favorite game IDs from local storage.
// If nothing is saved yet, it returns an empty array.
function getFavoriteIds() {
    return JSON.parse(localStorage.getItem('qqaFavorites') || '[]');
}

// Saves the updated favorite game IDs back to local storage.
function saveFavoriteIds(ids) {
    localStorage.setItem('qqaFavorites', JSON.stringify(ids));
}

// Combines the built-in ratings from the page with any extra ratings saved in local storage.
function getRatingsForGame(gameId, baseRatings) {
    const ratingsMap = JSON.parse(localStorage.getItem('qqaRatings') || '{}');
    const extraRatings = ratingsMap[gameId] || [];
    return [...baseRatings, ...extraRatings];
}

// Saves a new user rating for a game into local storage.
function saveRatingForGame(gameId, rating) {
    const ratingsMap = JSON.parse(localStorage.getItem('qqaRatings') || '{}');

    if (!ratingsMap[gameId]) {
        ratingsMap[gameId] = [];
    }

    ratingsMap[gameId].push(rating);
    localStorage.setItem('qqaRatings', JSON.stringify(ratingsMap));
}

// Calculates the average value of an array of ratings.
function calculateAverage(ratings) {
    if (!ratings.length) {
        return 0;
    }

    return ratings.reduce((sum, value) => sum + value, 0) / ratings.length;
}

// Returns "vote" or "votes" depending on the number.
function getVoteLabel(voteCount) {
    return voteCount === 1 ? 'vote' : 'votes';
}

// Creates a row of stars in a given container.
// It can either be display-only or interactive, depending on the arguments.
function renderStars(container, average, interactive, onRate) {
    container.innerHTML = '';
    const rounded = Math.round(average);

    // Helper function that fills the correct number of stars.
    function paintStars(value) {
        const stars = container.querySelectorAll('.star');

        stars.forEach((star, index) => {
            if (index < value) {
                star.classList.add('filled');
            } else {
                star.classList.remove('filled');
            }
        });
    }

    // Creates five stars.
    for (let i = 1; i <= 5; i++) {
        const star = document.createElement('span');
        star.textContent = '★';
        star.className = i <= rounded ? 'star filled' : 'star';

        // If the stars are interactive, allow hover preview and click rating.
        if (interactive) {
            star.classList.add('clickable-star');

            star.addEventListener('mouseenter', function () {
                paintStars(i);
            });

            star.addEventListener('click', function () {
                onRate(i);
            });
        }

        container.appendChild(star);
    }

    // When the mouse leaves an interactive star row, restore the saved rounded rating.
    if (interactive) {
        container.addEventListener('mouseleave', function () {
            paintStars(rounded);
        });
    }
}

// Updates the average rating, vote count, and displayed stars on one game card.
function updateCardDisplay(card) {
    const gameId = card.dataset.id;
    const baseRatings = card.dataset.ratings ? card.dataset.ratings.split(',').map(Number).filter(Number.isFinite) : [];
    const ratings = getRatingsForGame(gameId, baseRatings);
    const average = calculateAverage(ratings);
    const votes = ratings.length;

    card.querySelector('.avg-rating').textContent = average.toFixed(1);
    card.querySelector('.vote-count').textContent = votes;
    card.querySelector('.vote-label').textContent = getVoteLabel(votes);

    const starContainer = card.querySelector('.display-stars');
    renderStars(starContainer, average, false, null);
}

// Updates the appearance of a favorite heart button.
function updateFavoriteButtonState(button, gameId) {
    const favorites = getFavoriteIds();
    const isFavorite = favorites.includes(Number(gameId));

    button.textContent = isFavorite ? '♥' : '♡';
    button.classList.toggle('favorite-on', isFavorite);
}

// Adds or removes a game from favorites, then updates button states.
function toggleFavorite(gameId, button) {
    const favorites = getFavoriteIds();
    const numericId = Number(gameId);
    const existingIndex = favorites.indexOf(numericId);

    if (existingIndex >= 0) {
        favorites.splice(existingIndex, 1);
    } else {
        favorites.push(numericId);
    }

    saveFavoriteIds(favorites);

    if (button && button.classList) {
        updateFavoriteButtonState(button, numericId);
    }

    const modalButton = document.getElementById('modalFavoriteButton');
    if (modalButton && modalButton.dataset.gameId === String(numericId)) {
        updateModalFavoriteButton(numericId);
    }
}

// Changes the favorite button text inside the modal.
function updateModalFavoriteButton(gameId) {
    const modalButton = document.getElementById('modalFavoriteButton');
    const favorites = getFavoriteIds();
    const isFavorite = favorites.includes(Number(gameId));

    modalButton.textContent = isFavorite ? 'Remove Favorite' : 'Add to Favorites';
    modalButton.dataset.gameId = gameId;
}

// Opens the Quick View modal and fills it with the selected game's information.
function openGameModal(gameId) {
    const card = document.querySelector(`.game-card[data-id='${gameId}']`);
    const baseRatings = card.dataset.ratings ? card.dataset.ratings.split(',').map(Number).filter(Number.isFinite) : [];
    const ratings = getRatingsForGame(gameId, baseRatings);
    const average = calculateAverage(ratings);
    const votes = ratings.length;

    document.getElementById('modalTitle').textContent = card.dataset.title;
    document.getElementById('modalGenre').textContent = card.dataset.genre;
    document.getElementById('modalYear').textContent = card.dataset.year;
    document.getElementById('modalDescription').textContent = card.dataset.description;
    document.getElementById('modalRating').textContent = average.toFixed(1);
    document.getElementById('modalVotes').textContent = `${votes} ${getVoteLabel(votes)}`;
    document.getElementById('modalImage').src = `/images/${card.dataset.image}`;
    document.getElementById('modalImage').alt = card.dataset.title;

    // Builds the interactive modal star row.
    const modalStars = document.getElementById('modalStars');
    renderStars(modalStars, average, true, function (rating) {
        saveRatingForGame(gameId, rating);
        updateAllGameDisplays();
        openGameModal(gameId);
    });

    // Wires the modal favorite button to the selected game.
    const modalFavoriteButton = document.getElementById('modalFavoriteButton');
    modalFavoriteButton.onclick = function () {
        toggleFavorite(gameId, null);
        updateFavoriteButtons();
        updateModalFavoriteButton(gameId);
    };

    updateModalFavoriteButton(gameId);
    document.getElementById('gameModal').style.display = 'flex';
}

// Closes the Quick View modal.
function closeGameModal() {
    document.getElementById('gameModal').style.display = 'none';
}

// Filters the Games page cards based on the search box text.
function filterGames() {
    const search = document.getElementById('gameSearch').value.toLowerCase();
    const cards = document.querySelectorAll('.game-card');

    cards.forEach(card => {
        const title = card.dataset.title.toLowerCase();
        const genre = card.dataset.genre.toLowerCase();
        const matches = title.includes(search) || genre.includes(search);

        card.style.display = matches ? '' : 'none';
    });
}

// Sorts the Games page cards by the selected sort option.
function sortGames() {
    const grid = document.getElementById('gameGrid');
    if (!grid) return;

    const sortValue = document.getElementById('sortGames').value;
    const cards = Array.from(grid.querySelectorAll('.game-card'));

    cards.sort((a, b) => {
        if (sortValue === 'title') {
            return a.dataset.title.localeCompare(b.dataset.title);
        }

        if (sortValue === 'year') {
            return Number(a.dataset.year) - Number(b.dataset.year);
        }

        if (sortValue === 'rating') {
            return Number(b.querySelector('.avg-rating').textContent) - Number(a.querySelector('.avg-rating').textContent);
        }

        if (sortValue === 'votes') {
            return Number(b.querySelector('.vote-count').textContent) - Number(a.querySelector('.vote-count').textContent);
        }

        return Number(a.dataset.defaultorder) - Number(b.dataset.defaultorder);
    });

    cards.forEach(card => grid.appendChild(card));
}

// Updates every favorite heart button on the page.
function updateFavoriteButtons() {
    document.querySelectorAll('.favorite-toggle').forEach(button => {
        const gameId = button.closest('[data-id]').dataset.id;
        updateFavoriteButtonState(button, gameId);
    });
}

// Refreshes all rating displays across cards and the details page.
function updateAllGameDisplays() {
    document.querySelectorAll('.game-card').forEach(card => updateCardDisplay(card));

    const detailsCard = document.getElementById('detailsCard');
    if (detailsCard) {
        updateDetailsDisplay(detailsCard);
    }
}

// Updates the Details page rating and vote display.
function updateDetailsDisplay(detailsCard) {
    const gameId = detailsCard.dataset.id;
    const baseRatings = detailsCard.dataset.ratings ? detailsCard.dataset.ratings.split(',').map(Number).filter(Number.isFinite) : [];
    const ratings = getRatingsForGame(gameId, baseRatings);
    const average = calculateAverage(ratings);
    const votes = ratings.length;

    document.getElementById('detailsAverage').textContent = average.toFixed(1);
    document.getElementById('detailsVotes').textContent = votes;
    document.getElementById('detailsVoteLabel').textContent = getVoteLabel(votes);

    renderStars(document.getElementById('detailsDisplayStars'), average, false, null);
    renderStars(document.getElementById('detailsInteractiveStars'), average, true, function (rating) {
        saveRatingForGame(gameId, rating);
        updateAllGameDisplays();
    });
}

// Initializes features that only exist on the Details page.
function initializeDetailsPage() {
    const detailsCard = document.getElementById('detailsCard');
    if (!detailsCard) return;

    updateFavoriteButtons();
    updateDetailsDisplay(detailsCard);
}

// Handles the fake contact form submission.
function submitContactForm(event) {
    event.preventDefault();
    document.getElementById('contactFeedback').textContent = 'Message sent. Our neon support squad will get back to you soon.';
    event.target.reset();
    return false;
}

// Runs common setup once the page finishes loading.
window.addEventListener('DOMContentLoaded', function () {
    updateAllGameDisplays();
    updateFavoriteButtons();
});

// Allows clicking outside the modal to close it.
window.onclick = function (event) {
    const modal = document.getElementById('gameModal');

    if (modal && event.target === modal) {
        closeGameModal();
    }
};
