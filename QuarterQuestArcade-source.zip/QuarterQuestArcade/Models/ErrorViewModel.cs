namespace QuarterQuestArcade.Models
{
    // Stores error information used by the shared MVC error page.
    public class ErrorViewModel
    {
        // Holds the current request ID so the error can be traced if needed.
        public string? RequestId { get; set; }

        // Returns true when a request ID exists and should be displayed on the page.
        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
