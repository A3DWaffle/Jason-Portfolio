namespace QuarterQuestArcade.Models
{
    // Represents one arcade game displayed in the application.
    public class Game
    {
        // Stores the unique ID for each game.
        public int Id { get; set; }

        // Stores the game title shown on cards and details pages.
        public string Title { get; set; } = string.Empty;

        // Stores the genre of the game, such as racer or platformer.
        public string Genre { get; set; } = string.Empty;

        // Stores the fictional release year for the game.
        public int Year { get; set; }

        // Stores the main description text for the game.
        public string Description { get; set; } = string.Empty;

        // Stores the image file name used from the wwwroot/images folder.
        public string ImageName { get; set; } = string.Empty;

        // Stores the individual ratings for the game.
        // These act as the original built-in ratings before local ratings are added in JavaScript.
        public int[] Ratings { get; set; } = Array.Empty<int>();

        // Counts how many ratings the game currently has.
        public int VoteCount => Ratings?.Length ?? 0;

        // Calculates the average rating for the game.
        public double AverageRating => VoteCount == 0 ? 0 : Ratings.Average();

        // Automatically returns "vote" or "votes" depending on how many ratings exist.
        public string VoteLabel => VoteCount == 1 ? "vote" : "votes";
    }
}
