// Creates the builder that sets up services and configuration for the ASP.NET Core app.
var builder = WebApplication.CreateBuilder(args);

// Registers MVC services so the project can use controllers and Razor views.
builder.Services.AddControllersWithViews();

// Builds the application after services have been configured.
var app = builder.Build();

// Configures the production error pipeline.
if (!app.Environment.IsDevelopment())
{
    // Sends users to the home page if an unhandled error occurs in production.
    app.UseExceptionHandler("/Games/Index");

    // Enables HTTP Strict Transport Security for safer HTTPS behavior.
    app.UseHsts();
}

// Redirects HTTP requests to HTTPS.
app.UseHttpsRedirection();

// Allows the app to serve static files such as CSS, JavaScript, and images from wwwroot.
app.UseStaticFiles();

// Adds routing support so URLs can be matched to controller actions.
app.UseRouting();

// Adds authorization middleware to the request pipeline.
app.UseAuthorization();

// Sets the default MVC route for the application.
// If no controller or action is specified, the app loads GamesController and Index().
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Games}/{action=Index}/{id?}");

// Starts the web application.
app.Run();
