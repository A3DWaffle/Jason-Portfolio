using Microsoft.AspNetCore.Mvc;
using QuarterQuestArcade.Models;

namespace QuarterQuestArcade.Controllers
{
    // Controls the main pages of the Quarter Quest Arcade application.
    public class GamesController : Controller
    {
        // Stores the arcade game data used by the site.
        // This project keeps the data in memory instead of using a database.
        private static readonly List<Game> games = new()
        {
            new Game
            {
                Id = 1,
                Title = "Laser Lobster IV",
                Genre = "Space Shooter",
                Year = 1992,
                Description = "Pilot a heroic cyber-lobster across the stars and blast goofy sea mutants, robotic sharks, and jelly invaders in this bright and ridiculous arcade shooter.",
                ImageName = "laser-lobster-iv.png",
                Ratings = new[] { 5, 5, 4, 5, 4, 5 }
            },
            new Game
            {
                Id = 2,
                Title = "Rocket Gogo Pogo",
                Genre = "Platformer",
                Year = 1990,
                Description = "Bounce, boost, and panic your way through neon towers and chaotic trap zones using a rocket-powered pogo stick built with absolutely no concern for safety.",
                ImageName = "rocket-gogo-pogo.png",
                Ratings = new[] { 4, 4, 5, 4, 4 }
            },
            new Game
            {
                Id = 3,
                Title = "Brick Battalion",
                Genre = "Brick Breaker",
                Year = 1991,
                Description = "Command a heavily armed paddle tank and smash military-grade brick walls in a dramatic over-the-top twist on the classic brick-breaker formula.",
                ImageName = "brick-battalion.png",
                Ratings = new[] { 5, 4, 4, 5, 5 }
            },
            new Game
            {
                Id = 4,
                Title = "Turbo Cruise XL",
                Genre = "Arcade Racer",
                Year = 1994,
                Description = "Burn neon highways, dodge ridiculous traffic, and speed down impossible coastal roads in the loudest and flashiest cruising game ever created.",
                ImageName = "turbo-cruise-xl.png",
                Ratings = new[] { 5, 5, 5, 4, 5, 5 }
            },
            new Game
            {
                Id = 5,
                Title = "Mecha Custodian",
                Genre = "Puzzle Action",
                Year = 1993,
                Description = "Clean up alien slime, dodge weird hazards, and save a futuristic space station as a heroic janitor robot who takes sanitation very seriously.",
                ImageName = "mecha-custodian.png",
                Ratings = new[] { 4, 4, 4, 5 }
            },
            new Game
            {
                Id = 6,
                Title = "Cosmic Custard Commando",
                Genre = "Action Shooter",
                Year = 1995,
                Description = "Battle dessert-themed monsters across a candy-colored galaxy in a sugary sci-fi showdown where the custard fights back.",
                ImageName = "cosmic-custard-commando.png",
                Ratings = new[] { 5, 4, 5, 4, 5 }
            }
        };

        // Displays the home page.
        public IActionResult Index()
        {
            // Sends the first game title to the Home page as a featured cabinet.
            ViewData["FeaturedGame"] = games.First().Title;

            // Finds the game with the highest average rating and sends it to the Home page.
            ViewData["TopRated"] = games.OrderByDescending(g => g.AverageRating).First().Title;

            // Finds the game with the most votes and sends it to the Home page.
            ViewData["MostVoted"] = games.OrderByDescending(g => g.VoteCount).First().Title;

            return View();
        }

        // Displays the full game list.
        public IActionResult Games()
        {
            // Passes the entire list of games to the Games view.
            return View(games);
        }

        // Displays a details page for a single game.
        public IActionResult Details(int id)
        {
            // Looks for the game whose ID matches the route parameter.
            var game = games.FirstOrDefault(g => g.Id == id);

            // If the game is not found, return a 404 error.
            if (game == null)
            {
                return NotFound();
            }

            // If the game exists, pass it to the Details view.
            return View(game);
        }

        // Displays the hall of fame page.
        public IActionResult HallOfFame()
        {
            // Sorts games by highest rating first, then by highest vote count.
            var rankedGames = games
                .OrderByDescending(g => g.AverageRating)
                .ThenByDescending(g => g.VoteCount)
                .ToList();

            return View(rankedGames);
        }

        // Displays the about page.
        public IActionResult About()
        {
            return View();
        }

        // Displays the contact page.
        public IActionResult Contact()
        {
            return View();
        }
    }
}
