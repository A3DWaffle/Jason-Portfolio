# Quarter Quest Arcade

Quarter Quest Arcade is a retro-styled ASP.NET Core MVC catalog for six fictional arcade games. It pairs a reusable C# data model and MVC routes with responsive Razor views and browser-side interactions.

## Features

- Search and sort the six-game catalog
- Individual game detail pages
- Quick View modal
- Five-star ratings saved in `localStorage`
- Favorites saved in `localStorage`
- Hall of Fame ranking by average rating and vote count
- Responsive, original arcade-themed artwork and interface

## Stack

- C# and .NET 9
- ASP.NET Core MVC
- Razor views
- HTML, CSS, and vanilla JavaScript

## Run locally

Install the [.NET 9 SDK](https://dotnet.microsoft.com/download/dotnet/9.0), then run:

```bash
dotnet restore
dotnet run
```

Open the local address printed in the terminal. The default route opens the `GamesController` home page.

## Project structure

- `Controllers/GamesController.cs` contains routes and the in-memory game catalog.
- `Models/Game.cs` defines game data and calculated rating values.
- `Views/Games/` contains the catalog, details, Hall of Fame, About, and Contact pages.
- `wwwroot/css/site.css` contains the responsive visual system.
- `wwwroot/js/site.js` handles search, sorting, modals, favorites, and ratings.

## Notes

Ratings and favorites are intentionally stored in the browser for this portfolio project; no database or account is required.
